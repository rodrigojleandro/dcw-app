#!/bin/bash

docker run -itd -p 80:3000 docker pull rodrigoleandro/dcp-app:develop